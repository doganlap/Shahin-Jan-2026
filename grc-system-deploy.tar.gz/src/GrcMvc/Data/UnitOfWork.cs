using System;
using System.Threading.Tasks;
using GrcMvc.Data.Repositories;
using GrcMvc.Models.Entities;
using Microsoft.EntityFrameworkCore.Storage;

namespace GrcMvc.Data
{
    /// <summary>
    /// Implementation of Unit of Work pattern
    /// </summary>
    public class UnitOfWork : IUnitOfWork
    {
        private readonly GrcDbContext _context;
        private IDbContextTransaction? _transaction;
        private bool _disposed;

        // Lazy-loaded repositories
        private IGenericRepository<Risk>? _risks;
        private IGenericRepository<Control>? _controls;
        private IGenericRepository<Assessment>? _assessments;
        private IGenericRepository<Audit>? _audits;
        private IGenericRepository<AuditFinding>? _auditFindings;
        private IGenericRepository<Evidence>? _evidences;
        private IGenericRepository<Policy>? _policies;
        private IGenericRepository<PolicyViolation>? _policyViolations;
        private IGenericRepository<Workflow>? _workflows;
        private IGenericRepository<WorkflowExecution>? _workflowExecutions;

        public UnitOfWork(GrcDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        // Repository properties with lazy initialization
        public IGenericRepository<Risk> Risks =>
            _risks ??= new GenericRepository<Risk>(_context);

        public IGenericRepository<Control> Controls =>
            _controls ??= new GenericRepository<Control>(_context);

        public IGenericRepository<Assessment> Assessments =>
            _assessments ??= new GenericRepository<Assessment>(_context);

        public IGenericRepository<Audit> Audits =>
            _audits ??= new GenericRepository<Audit>(_context);

        public IGenericRepository<AuditFinding> AuditFindings =>
            _auditFindings ??= new GenericRepository<AuditFinding>(_context);

        public IGenericRepository<Evidence> Evidences =>
            _evidences ??= new GenericRepository<Evidence>(_context);

        public IGenericRepository<Policy> Policies =>
            _policies ??= new GenericRepository<Policy>(_context);

        public IGenericRepository<PolicyViolation> PolicyViolations =>
            _policyViolations ??= new GenericRepository<PolicyViolation>(_context);

        public IGenericRepository<Workflow> Workflows =>
            _workflows ??= new GenericRepository<Workflow>(_context);

        public IGenericRepository<WorkflowExecution> WorkflowExecutions =>
            _workflowExecutions ??= new GenericRepository<WorkflowExecution>(_context);

        public bool HasActiveTransaction => _transaction != null;

        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public async Task BeginTransactionAsync()
        {
            if (_transaction != null)
            {
                throw new InvalidOperationException("A transaction is already in progress.");
            }

            _transaction = await _context.Database.BeginTransactionAsync();
        }

        public async Task CommitTransactionAsync()
        {
            if (_transaction == null)
            {
                throw new InvalidOperationException("No transaction in progress to commit.");
            }

            try
            {
                await SaveChangesAsync();
                await _transaction.CommitAsync();
            }
            catch
            {
                await RollbackTransactionAsync();
                throw;
            }
            finally
            {
                await _transaction.DisposeAsync();
                _transaction = null;
            }
        }

        public async Task RollbackTransactionAsync()
        {
            if (_transaction == null)
            {
                throw new InvalidOperationException("No transaction in progress to rollback.");
            }

            try
            {
                await _transaction.RollbackAsync();
            }
            finally
            {
                await _transaction.DisposeAsync();
                _transaction = null;
            }
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _transaction?.Dispose();
                    _context.Dispose();
                }

                _disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}