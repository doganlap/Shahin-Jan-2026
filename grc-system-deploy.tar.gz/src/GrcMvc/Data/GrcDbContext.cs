using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using GrcMvc.Models.Entities;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace GrcMvc.Data
{
    public class GrcDbContext : IdentityDbContext<ApplicationUser>
    {
        public GrcDbContext(DbContextOptions<GrcDbContext> options)
            : base(options)
        {
        }

        // DbSets for all entities
        public DbSet<Risk> Risks { get; set; } = null!;
        public DbSet<Control> Controls { get; set; } = null!;
        public DbSet<Assessment> Assessments { get; set; } = null!;
        public DbSet<Audit> Audits { get; set; } = null!;
        public DbSet<AuditFinding> AuditFindings { get; set; } = null!;
        public DbSet<Evidence> Evidences { get; set; } = null!;
        public DbSet<Policy> Policies { get; set; } = null!;
        public DbSet<PolicyViolation> PolicyViolations { get; set; } = null!;
        public DbSet<Workflow> Workflows { get; set; } = null!;
        public DbSet<WorkflowExecution> WorkflowExecutions { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure Risk entity
            modelBuilder.Entity<Risk>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Name).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Category).HasMaxLength(100);
                entity.Property(e => e.Owner).HasMaxLength(100);
                entity.HasIndex(e => e.Name);
                entity.HasQueryFilter(e => !e.IsDeleted);
            });

            // Configure Control entity
            modelBuilder.Entity<Control>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.ControlId).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Name).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Category).HasMaxLength(100);
                entity.Property(e => e.Type).HasMaxLength(50);
                entity.Property(e => e.Frequency).HasMaxLength(50);
                entity.HasIndex(e => e.ControlId).IsUnique();
                entity.HasQueryFilter(e => !e.IsDeleted);

                entity.HasOne(e => e.Risk)
                    .WithMany(r => r.Controls)
                    .HasForeignKey(e => e.RiskId)
                    .OnDelete(DeleteBehavior.SetNull);
            });

            // Configure Assessment entity
            modelBuilder.Entity<Assessment>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.AssessmentNumber).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Name).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Type).HasMaxLength(50);
                entity.HasIndex(e => e.AssessmentNumber).IsUnique();
                entity.HasQueryFilter(e => !e.IsDeleted);

                entity.HasOne(e => e.Risk)
                    .WithMany(r => r.Assessments)
                    .HasForeignKey(e => e.RiskId)
                    .OnDelete(DeleteBehavior.SetNull);

                entity.HasOne(e => e.Control)
                    .WithMany(c => c.Assessments)
                    .HasForeignKey(e => e.ControlId)
                    .OnDelete(DeleteBehavior.SetNull);
            });

            // Configure Audit entity
            modelBuilder.Entity<Audit>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.AuditNumber).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Title).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Type).HasMaxLength(50);
                entity.HasIndex(e => e.AuditNumber).IsUnique();
                entity.HasQueryFilter(e => !e.IsDeleted);
            });

            // Configure AuditFinding entity
            modelBuilder.Entity<AuditFinding>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.FindingNumber).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Title).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Severity).HasMaxLength(20);
                entity.HasIndex(e => e.FindingNumber).IsUnique();
                entity.HasQueryFilter(e => !e.IsDeleted);

                entity.HasOne(e => e.Audit)
                    .WithMany(a => a.Findings)
                    .HasForeignKey(e => e.AuditId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // Configure Evidence entity
            modelBuilder.Entity<Evidence>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.EvidenceNumber).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Title).IsRequired().HasMaxLength(200);
                entity.Property(e => e.FileName).HasMaxLength(255);
                entity.HasIndex(e => e.EvidenceNumber).IsUnique();
                entity.HasQueryFilter(e => !e.IsDeleted);

                entity.HasOne(e => e.Assessment)
                    .WithMany(a => a.Evidences)
                    .HasForeignKey(e => e.AssessmentId)
                    .OnDelete(DeleteBehavior.SetNull);

                entity.HasOne(e => e.Audit)
                    .WithMany(a => a.Evidences)
                    .HasForeignKey(e => e.AuditId)
                    .OnDelete(DeleteBehavior.SetNull);

                entity.HasOne(e => e.Control)
                    .WithMany(c => c.Evidences)
                    .HasForeignKey(e => e.ControlId)
                    .OnDelete(DeleteBehavior.SetNull);
            });

            // Configure Policy entity
            modelBuilder.Entity<Policy>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.PolicyNumber).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Title).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Category).HasMaxLength(100);
                entity.Property(e => e.Version).HasMaxLength(20);
                entity.HasIndex(e => e.PolicyNumber).IsUnique();
                entity.HasQueryFilter(e => !e.IsDeleted);
            });

            // Configure PolicyViolation entity
            modelBuilder.Entity<PolicyViolation>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.ViolationNumber).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Severity).HasMaxLength(20);
                entity.HasIndex(e => e.ViolationNumber).IsUnique();
                entity.HasQueryFilter(e => !e.IsDeleted);

                entity.HasOne(e => e.Policy)
                    .WithMany(p => p.Violations)
                    .HasForeignKey(e => e.PolicyId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // Configure Workflow entity
            modelBuilder.Entity<Workflow>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.WorkflowNumber).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Name).IsRequired().HasMaxLength(200);
                entity.Property(e => e.Type).HasMaxLength(50);
                entity.Property(e => e.Category).HasMaxLength(100);
                entity.HasIndex(e => e.WorkflowNumber).IsUnique();
                entity.HasQueryFilter(e => !e.IsDeleted);
            });

            // Configure WorkflowExecution entity
            modelBuilder.Entity<WorkflowExecution>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.ExecutionNumber).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Status).HasMaxLength(50);
                entity.HasIndex(e => e.ExecutionNumber).IsUnique();
                entity.HasQueryFilter(e => !e.IsDeleted);

                entity.HasOne(e => e.Workflow)
                    .WithMany(w => w.Executions)
                    .HasForeignKey(e => e.WorkflowId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            // Configure ApplicationUser
            modelBuilder.Entity<ApplicationUser>(entity =>
            {
                entity.Property(e => e.FirstName).HasMaxLength(100);
                entity.Property(e => e.LastName).HasMaxLength(100);
                entity.Property(e => e.Department).HasMaxLength(100);
                entity.Property(e => e.JobTitle).HasMaxLength(100);
            });
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            foreach (var entry in ChangeTracker.Entries<BaseEntity>())
            {
                switch (entry.State)
                {
                    case EntityState.Added:
                        entry.Entity.CreatedDate = DateTime.UtcNow;
                        break;
                    case EntityState.Modified:
                        entry.Entity.ModifiedDate = DateTime.UtcNow;
                        break;
                }
            }

            return base.SaveChangesAsync(cancellationToken);
        }
    }
}