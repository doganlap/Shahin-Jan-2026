using System;
using System.Threading.Tasks;
using GrcMvc.Data.Repositories;
using GrcMvc.Models.Entities;

namespace GrcMvc.Data
{
    /// <summary>
    /// Unit of Work pattern for managing transactions across repositories
    /// </summary>
    public interface IUnitOfWork : IDisposable
    {
        // Repositories
        IGenericRepository<Risk> Risks { get; }
        IGenericRepository<Control> Controls { get; }
        IGenericRepository<Assessment> Assessments { get; }
        IGenericRepository<Audit> Audits { get; }
        IGenericRepository<AuditFinding> AuditFindings { get; }
        IGenericRepository<Evidence> Evidences { get; }
        IGenericRepository<Policy> Policies { get; }
        IGenericRepository<PolicyViolation> PolicyViolations { get; }
        IGenericRepository<Workflow> Workflows { get; }
        IGenericRepository<WorkflowExecution> WorkflowExecutions { get; }

        // Transaction management
        Task<int> SaveChangesAsync();
        Task BeginTransactionAsync();
        Task CommitTransactionAsync();
        Task RollbackTransactionAsync();
        bool HasActiveTransaction { get; }
    }
}